package recipefindermyapp.gohool.com.recipefinderapp.model

/**
 * Created by paulodichone on 7/8/17.
 */

    val LEFT_LINK: String = "http://www.recipepuppy.com/api/?i="
    val QUERY: String = "&q="
