package randombgappkotlinandroid.gohool.com.simplelist2_listview

class Person {
    var name: String? = null
    var age: Int? = null

}
