
fun main(args: Array<String>) {
    /*
       Addition
       Subtraction
     */

    var firstNum = 10
    var secondNum = 200

    //var result:Int?

   // result = firstNum + secondNum

    println("The Sum is ${firstNum + secondNum }")



}
