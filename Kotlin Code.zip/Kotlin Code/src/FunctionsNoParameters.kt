fun main(args: Array<String>) {

    helloThere()
}

fun helloThere() {
    println("Hello there")
}