fun main(args: Array<String>) {

    /*
       Variables = a little bucket where we can put information
       Types: String, Int, Double, Boolean, Float, Char

       String;
       Int = number
       Double type 23.00, 21.89
       Boolean = True, or False
       Float = fraction 0.6, 2.5, 1.4 etc
       Char = character = h, b, $, & ..
     */


    var myFloat = 0.5
    var newFloat: Float? = null

    newFloat = 0.6f





    println(newFloat)




}

