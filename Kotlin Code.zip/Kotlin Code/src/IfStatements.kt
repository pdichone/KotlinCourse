
fun main(args: Array<String>) {
    /*
       If statements
     */
    var firstNum = 5
    var secondNum = 6

//    if (firstNum > secondNum) {
//        println("Yes")
//    }

    if (firstNum >= secondNum)  println("Yes") else println("No")

//    if (firstNum >= secondNum) {
//        println("Yes")
//    }else {
//        println("No")
//    }



}

