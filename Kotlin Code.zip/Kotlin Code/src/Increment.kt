
fun main(args: Array<String>) {
    /*
       Addition (+)
       Subtraction (-)
       Multiplication(*)
       Division (/)
       Remainder (%) "what remains after dividing two numbers"
       Increment +
       Decrement -

     */


    var firstNum = 8
    var secondNum = 3

    var incr =  firstNum + 1
    var decrement = firstNum - 1

    println(--firstNum) // firstNum - 1

    println(++firstNum) // firstNum + 1




}
