
fun main(args: Array<String>) {

    /*
       Variables = a little bucket where we can put information
       Types: String, Int, Double, Boolean, Float, Char
       String;
       Int
     */

    var country:String = "Spain"
   // var country = "Spain"

    //country = "Spain"

    println(country)

}