fun main(args: Array<String>) {
    //While Loop

    var counter = 0
    while (counter < 5) {
        println("Counting... $counter")

        counter++// counter = counter + 1
    }
    println("Out of While loop")
}
