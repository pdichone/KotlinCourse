
fun main(args: Array<String>) {
    /*
        Convert Data types

     */
    var age: Int = 3
    var bloodPressure = 89.0
    age = bloodPressure.toInt() // integer





    println(age )





}
