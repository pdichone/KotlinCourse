
fun main(args: Array<String>) {
    /*
        Conditional Operators
        <,
        >
        ==
        !=
        <=
        >=

     */
    var firstNum = 5
    var secondNum = 6

    //println(firstNum > secondNum) // returns a boolean ==> true or false
   // println(firstNum < secondNum)

    //println(firstNum == secondNum) // equal conditional operator
   // println(firstNum != secondNum)

   // println(firstNum <= secondNum) //less than or equal
    println(firstNum >= secondNum) //greater than or equal








}

